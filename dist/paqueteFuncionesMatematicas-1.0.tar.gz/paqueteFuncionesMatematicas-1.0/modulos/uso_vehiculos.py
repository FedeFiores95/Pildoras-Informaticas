from modulo_vehiculos import *

miCoche=Vehiculos("Mazda","MX5")

miCoche.arrancar()
miCoche.estado()