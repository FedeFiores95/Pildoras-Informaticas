from setuptools import setup

setup(

	name="paqueteFuncionesMatematicas",
	version="1.0",
	description="Realiza operaciones matematicas simples",
	author="ElFiores",
	author_email="Fedefiores95@gmail.com",
	packages=["modulos"]

	)